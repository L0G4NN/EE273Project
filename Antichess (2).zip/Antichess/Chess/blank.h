/* filename blank.h
 * [Description]
 * Last updated: [DD:MM:YYYY]
 * Description of latest update:
 *
 *
 */

#ifndef BLANK_H
#define BLANK_H
#include "Pieces.h"

#endif // BLANK_H


class Blank:public Pieces{

public:
    Blank();

private:
    QPixmap icon;
};
