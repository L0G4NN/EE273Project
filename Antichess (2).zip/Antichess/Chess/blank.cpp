/* filename blank.cpp
 * [Description]
 * Last updated: [DD:MM:YYYY]
 * Description of latest update:
 *
 *
 */

#include "blank.h"


Blank::Blank(){

    setIcon("../Antichess/images/Pieces/noimage.svg");
}


